export class CustomerModel{
    name:string='';
    email:string='';
    contact:string='';
    address:string='';
}